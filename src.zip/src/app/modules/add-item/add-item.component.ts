import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig} from '@angular/material/dialog';
import { NgForm } from '@angular/forms';
import { InventoryService } from 'src/app/shared/services/inventory.service';
import {ThemePalette} from '@angular/material/core';


export interface Tag {
  name: string;
  selected: boolean;
  color: ThemePalette;
  subtags?: Tag[];
}


@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<AddItemComponent>, @Inject(MAT_DIALOG_DATA) public data:any, private apiService:InventoryService) { }

  tag: Tag = {
    name: 'Indeterminate',
    selected: false,
    color: 'primary',
    subtags: [
      {name: 'HP', selected: false, color: 'accent'},
      {name: 'SAMSUNG', selected: false, color: 'accent'},
      {name: 'APPLE', selected: false, color: 'accent'},
      {name: 'COMPUTER', selected: false, color: 'accent'},
      {name: 'ACCESSORY', selected: false, color: 'accent'},
      {name: 'DELL', selected: false, color: 'accent'},
      {name: 'LENOVO', selected: false, color: 'accent'},
      
    ],
  };

  allSelected: boolean = false;

  updateAllSelected() {
    this.allSelected = this.tag.subtags != null && this.tag.subtags.every(t => t.selected);
  }

  someSelected(): boolean {
    if (this.tag.subtags == null) {
      return false;
    }
    return this.tag.subtags.filter(t => t.selected).length > 0 && !this.allSelected;
  }

  setAll(selected: boolean) {
    this.allSelected = selected;
    if (this.tag.subtags == null) {
      return;
    }
    this.tag.subtags.forEach(t => (t.selected = selected));
  }


  ngOnInit(): void {
  }
   //Submission of form method
   onSubmit(f:NgForm){
    console.log(f.value)

    const payload = {
      "item-name": f.value.name,
      "item-description": f.value.description,
      "item-state": f.value.state,
      "item-category": f.value.selected,

      "item-date": f.value.date,
      "item-tag": this.tag.subtags,
      "item-img": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQy4MchLKUmVNdpGEcYNuzfc3g64grbtup9lQ&usqp=CAU"
    }

    this.apiService.AddItem(payload).subscribe(
      (res)=>{
        console.log(res);
      }
    )
  }
  //Closing modal
  closeModal(){
    this.dialogRef.close();
  }

}
